#include <iostream>
#include <fstream>
#include <string>
#include <termios.h>
#include <unistd.h>

using namespace std;

//Getch function for MacOs
char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0)
        perror("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        perror("tcsetattr ~ICANON");
    return buf;
}


void encryptFile(const string& fileName, int shift) {
    ifstream inFile(fileName);
    if (!inFile) {
        cout << "Error opening file!" << endl;
        return;
    }

    ofstream outFile("encrypted_" + fileName);
    char ch;
    while (inFile.get(ch)) {

        if (isalpha(ch)) {
            char base = islower(ch) ? 'a' : 'A';
            ch = (ch - base + shift) % 26 + base;
        }
        outFile.put(ch);
    }

    inFile.close();
    outFile.close();

    cout << "File encrypted successfully! Encrypted file: encrypted_" << fileName << endl;
}

void decryptFile(const string& fileName, int shift) {
    ifstream inFile(fileName);
    if (!inFile) {
        cout << "Error opening file!" << endl;
        return;
    }

    ofstream outFile("decrypted_" + fileName);
    char ch;
    while (inFile.get(ch)) {
        if (isalpha(ch)) {
            char base = islower(ch) ? 'a' : 'A';
            ch = (ch - base - shift + 26) % 26 + base;
        }
        outFile.put(ch);
    }

    inFile.close();
    outFile.close();

    cout << "File decrypted successfully! Decrypted file: decrypted_" << fileName << endl;
}

void waitForKeyPress() {
    cout << "Press any key to continue..." << endl;
    getch();
}

int main() {
    int choice, shift;
    string fileName;

    while (true) {
        system("clear");
        cout<<"*************************************\n";
        cout<<"*    FILE ENCRYPTION/DECRYPTION     *\n";
        cout<<"*************************************\n\n";
        cout << "\nFile Encryption/Decryption Menu:" << endl;
        cout << "1. Encrypt a file" << endl;
        cout << "2. Decrypt a file" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 3) {
            cout << "Exiting program." << endl;
            break;
        }

        cout << "Enter the file name: ";
        cin >> fileName;
        cout << "Enter the shift value (1-25): ";
        cin >> shift;

        switch (choice) {
            case 1:
                encryptFile(fileName, shift);
                waitForKeyPress();
                break;
            case 2:
                decryptFile(fileName, shift);
                waitForKeyPress();
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    }

    return 0;
}
