#include <iostream>
#include <vector>
#include <string>
#include <termios.h>
#include <unistd.h>

using namespace std;

//Getch function for MacOs
char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0)
        perror("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        perror("tcsetattr ~ICANON");
    return buf;
}

class Task {
public:
    string description;
    bool isCompleted;

    Task(string desc) {
        description = desc;
        isCompleted = false;
    }

    void markAsCompleted() {
        isCompleted = true;
    }

    void displayTask(int index) const {
        cout << index + 1 << ". " << description;
        if (isCompleted)
            cout << " [Completed]";
        cout << endl;
    }
};

class ToDoList {
private:
    vector<Task> tasks;

public:
    // Add a new task
    void addTask(const string& description) {
        tasks.push_back(Task(description));
        cout << "Task added: " << description << endl;
    }

    // Mark task as completed
    void completeTask(int index) {
        if (index < 1 || index > tasks.size()) {
            cout << "Invalid task number!" << endl;
            return;
        }
        tasks[index - 1].markAsCompleted();
        cout << "Task marked as completed: " << tasks[index - 1].description << endl;
    }

    // Display all tasks
    void displayTasks() const {
        if (tasks.empty()) {
            cout << "No tasks in your list." << endl;
            return;
        }
        cout << "Your tasks: " << endl;
        for (size_t i = 0; i < tasks.size(); ++i) {
            tasks[i].displayTask(i);
        }
    }
};

void displayMenu() {
    cout<<"*************************************\n";
    cout<<"*            TO-DO LIST             *\n";
    cout<<"*************************************\n\n";
    cout << "\nTo-Do List Menu:" << endl;
    cout << "1. Add Task" << endl;
    cout << "2. Mark Task as Completed" << endl;
    cout << "3. View Tasks" << endl;
    cout << "4. Exit" << endl;
    cout << "Choose an option: ";
}

void waitForKeyPress() {
    cout << "Press any key to continue..." << endl;
    getch();
}

int main() {
    ToDoList toDoList;
    int choice;
    string description;
    int taskNumber;

    while (true) {
        system("clear");
        displayMenu();
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter task description: ";
                cin.ignore();
                getline(cin, description);
                toDoList.addTask(description);
                waitForKeyPress();
                break;
            case 2:
                cout << "Enter task number to mark as completed: ";
                cin >> taskNumber;
                toDoList.completeTask(taskNumber);
                waitForKeyPress();
                break;
            case 3:
                toDoList.displayTasks();
                waitForKeyPress();
                break;
            case 4:
                cout << "Exiting the application..." << endl;
                return 0;
            default:
                cout << "Invalid option. Please try again." << endl;
        }
    }
}
